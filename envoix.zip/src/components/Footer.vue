<script lang="ts">

</script>
<template>
                <footer class="border-t border-blue-1100 lg:pt-[67px] pt-10 md:pb-[75px] pb-[53px]">
                <div class="max-w-[1728px] mx-auto  3xl:px-[160px] 2xl:px-20 xl:px-10 md:px-8 px-4">
                    <div class="flex lg:flex-nowrap flex-wrap gap-6">
                        <div class="lg:w-3/4 w-full">
                            <div class="lg:flex 3xl:max-w-[928px] max-w-[828px] justify-between">
                                <div class="md:mb-0 mb-[60px]">
                                    <h4 class="text-lg mb-[60px] text-black leading-[102%] font-bold">Solutions</h4>
                                    <ul>
                                        <li>
                                            <a href="#" class="text-lg transition-all ease-out duration-500 hover:text-blue-1000 block mb-[60px] text-black leading-[102%] font-normal">Features</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg transition-all ease-out duration-500 hover:text-blue-1000 block text-black leading-[102%] font-normal">FAQ</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="md:mb-0 mb-[60px]">
                                    <h4 class="text-lg mb-[60px] text-black leading-[102%] block font-bold">Support</h4>
                                    <ul>
                                        <li>
                                            <a href="#" class="text-lg mb-[60px] transition-all ease-out duration-500 hover:text-blue-1000 text-black leading-[102%] block font-normal">Preise</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg text-black transition-all ease-out duration-500 hover:text-blue-1000 leading-[102%] block font-normal">Dokumentation</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="md:mb-0 mb-[60px]">
                                    <h4 class="text-lg mb-[60px] text-black transition-all ease-out duration-500 hover:text-blue-1000 leading-[102%] block font-bold">Company</h4>
                                    <ul>
                                        <li>
                                            <a href="#" class="text-lg mb-[60px] transition-all ease-out duration-500 hover:text-blue-1000 text-black block leading-[102%] font-normal">Über uns</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg text-black transition-all ease-out duration-500 hover:text-blue-1000 mb-[60px] block leading-[102%] font-normal">Blog</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg text-black transition-all ease-out duration-500 hover:text-blue-1000 mb-[60px] block leading-[102%] font-normal">Jobs</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg text-black transition-all ease-out duration-500 hover:text-blue-1000 leading-[102%] block font-normal">Partner</a>
                                        </li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 class="text-lg mb-[60px] text-black leading-[102%] block font-bold">Legal</h4>
                                    <ul>
                                        <li>
                                            <a href="#" class="text-lg mb-[60px] transition-all ease-out duration-500 hover:text-blue-1000 text-black leading-[102%] block font-normal">Impressum</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg mb-[60px] transition-all ease-out duration-500 hover:text-blue-1000 text-black leading-[102%] block font-normal">Datenschutz</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg mb-[60px] transition-all ease-out duration-500 hover:text-blue-1000 text-black leading-[102%] block font-normal">AGB</a>
                                        </li>
                                        <li>
                                            <a href="#" class="text-lg text-black transition-all ease-out duration-500 hover:text-blue-1000 leading-[102%] font-normal block">Widerrufsbelehrung</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="lg:w-1/4 w-full lg:mt-0 mt-11">
                            <div class="lg:max-w-[282px] text-center lg:block flex items-center justify-between ml-auto">
                                <img src="@/assets/images/footer-logo1.png" class="md:w-auto w-[133px] inline-block mb-2" alt="">
                                <img src="@/assets/images/logo-2.png" class="md:w-auto w-[163px] inline-block" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
</template>